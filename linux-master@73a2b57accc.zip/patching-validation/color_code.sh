#!/bin/bash
Report=/opt/patching-validation/report_patch.txt
vmwaretool56=10.1.0.57774
vmwaretool7=10.1.5.59732
/bin/sed -i -e 's/'$vmwaretool56'/\<font color=\"green\"\>'$vmwaretool56'<\/font\>/g' $Report
/bin/sed -i -e 's/'$vmwaretool7'/\<font color=\"green\"\>'$vmwaretool7'<\/font\>/g' $Report
/bin/sed -i -e 's/Current/\<font color=\"green\"\>Current<\/font\>/g' $Report 
/bin/sed -i -e 's/running/\<font color=\"green\"\>running<\/font\>/g' $Report 

echo "<body bgcolor="LightBlue">"
Model=$(sudo /usr/sbin/dmidecode | grep "Product Name:" | grep -v Desk | awk  '{print $4 $5}')
echo "<td>"
echo $Model
echo "</td>"
if [ $Model == VirtualPlatform ]
then
vmware_tool=$(sudo /usr/bin/vmware-toolbox-cmd -v|awk '{print $1}')
echo "<td><font color="Red">"
echo $vmware_tool
echo "</font></td>"
else 
vmware_tool=$(echo "NA")
echo "<td><font color="Green">"
echo $vmware_tool
echo "</font></td>"
fi

OS=$(sudo cat /etc/redhat-release|awk '{print $7}')
if grep -q -i "release 5" /etc/redhat-release
then
echo "<td bgcolor="ForestGreen">"
echo $OS
echo "</td>"
elif grep -q -i "release 6" /etc/redhat-release
then
echo "<td bgcolor="ForestGreen">"
echo $OS
echo "</td>"
else 
echo "<td bgcolor="MediumPurple">"
echo $OS
echo "</td>"
fi

kernel=$(uname -r)
RH5=2.6.18-437.el5
RH6=2.6.32-754.12.1.el6.x86_64
RH7=3.10.0-957.12.1.el7.x86_64
if [ $kernel == $RH5 ]
then
echo "<td bgcolor="ForestGreen">"
echo $kernel
echo "</td>"
elif [ $kernel == $RH6 ] 
then
echo "<td bgcolor="ForestGreen">"
echo $kernel
echo "</td>"
elif [ $kernel == $RH7 ]
then
echo "<td bgcolor="ForestGreen">"
echo $kernel
echo "</td>"
else
echo "<td bgcolor="MediumPurple">"
echo $kernel
echo "</td>"
fi

uptime=$(uptime|awk '{print $3,$4}')
echo "<td>"
echo $uptime
echo "</td>"

days_chk=$(uptime|awk '/days?/ {print $3; next}; {print 0}')
if [ $days_chk -ne 0 ] 
then
boot_chk=$(echo "Missed Re-boot'?'")
echo "<td bgcolor="LightCoral">"
echo $boot_chk
echo "</td>"
else
boot_chk=$(echo "Reboot Ok")
echo "<td bgcolor="SpringGreen">"
echo $boot_chk
echo "</font></td>"
fi

if grep -q -i "release 4" /etc/redhat-release
then
patchupdate=$(sudo cat  /var/log/up2date|awk '{print $2,$3,$4}'|tail -1)
echo "<td>"
echo $patchupdate
echo "</td>"
else
patchupdate=$(sudo cat  /var/log/yum.log|awk '{print $1,$2,$3}'|tail -1)
echo "<td>"
echo $patchupdate
echo "</td>"
fi

date=`date|awk '{print $2,$3}'`
pkg_erase=`sudo cat /var/log/yum.log|grep Erased|grep "$date"|wc -l`
if [ $pkg_erase -gt 0 ]
  then
pkgerase=$(echo "$pkg_erase pkg erased")
echo "<td><font color="red">"
echo $pkgerase
echo "</font></td>"
else
pkgerase=$(echo "No pkg removed")
echo "<td><font color="green">"
echo $pkgerase
echo "</font></td>"
fi

df_old=$(sudo cat /root/backup/`sudo ls -lrt /root/backup | tail -1 | awk '{print $9}'`/df-hP_out | egrep -v "home|depots|spp2014|autofs" |wc -l)
echo "<td>"
echo $df_old
echo "</td>"
df_new=$(df -hP | egrep -v "home|depots|spp2014|autofs" |wc -l)
echo "<td>"
echo $df_new
echo "</td>"
#if [ $df_old -eq  $df_new ]
if [ $df_new -lt  $df_old ]
   then
mount_compare=$(echo "Mount missing")
echo "<td><b><font color="Red">"
echo $mount_compare
echo "</font></b></td>"
else
mount_compare=$(echo "No Mount mismatch")
echo "<td><font color="green">"
echo $mount_compare
echo "</font></td>"
fi

#pd=$(ps -ef|grep pd$|grep u01)
#echo "<td>"
#echo $pd
#echo "</td>"
root=$(df -hPl /|awk '{print $4,$5}'|tail -1)
echo "<td bgcolor=Orange>"
echo $root
echo "</td>"
boot=$(df -hPl /boot |awk '{print $4,$5}'|tail -1)
echo "<td bgcolor=White>"
echo $boot
echo "</td>"
var=$(df -hPl /var|awk '{print $4,$5}'|tail -1)
echo "<td bgcolor=OliveDrab>"
echo $var
echo "</td>"

oam=/usr/sbin/oracleasm
if [ -e $oam ]
then
current_oracleasm=$(sudo oracleasm listdisks|wc -l)
oasm_old=$(sudo cat /root/backup/`sudo ls -lrt /root/backup|tail -1|awk '{print $9}'`/etc_init.d_oracleasm_listdisks|wc -l)
oasm_compare=$(echo "$current_oracleasm and old count $oasm_old")
echo "<td><b>"
echo $oasm_compare
echo "</b></td>"
else
oracleasm=$(echo "No")
echo "<td><font color="green">"
echo $oracleasm
echo "</font></td>"
fi
VCS=/opt/VRTS/bin/hastatus
if [ -e $VCS ]
  then
Veritas=$(echo "VCS Cluster exist")
echo "<td><font color="Red">"
echo $Veritas
echo "</font></td>"
  else
Veritas=$(echo "No")
echo "<td><font color="green">"
echo $Veritas
echo "</font></td>"
fi
RH=/usr/sbin/clustat
if [ -e $RH ]
  then
redhat=$(echo "RHC exist")
echo "<td><font color="Red">"
echo $redhat
echo "</font></td>"
 else
redhat=$(echo "No")
echo "<td><font color="green">"
echo $redhat
echo "</font></td>"
fi
if grep -q -i "release 7" /etc/redhat-release
then 
puppet=$(sudo /bin/systemctl status puppet.service|egrep "Active|Main"|cut -d: -f2)
echo "<td>"
echo $puppet
echo "</td>"
else
puppet=$(sudo /etc/init.d/puppet status)
echo "<td>"
echo $puppet
echo "</td>"
fi
rhn=$(sudo subscription-manager status|grep ":"|cut -d: -f2)
echo "<td>"
echo $rhn
echo "</td>"
echo "</body>"

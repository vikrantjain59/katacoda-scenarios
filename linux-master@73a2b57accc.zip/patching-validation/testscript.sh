#!/bin/bash
uptime
uname -a
date

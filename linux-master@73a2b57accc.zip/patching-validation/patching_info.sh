#! /bin/sh
#************************************************************************************************************************
#Script to perform FY18 Patching Validation
#************************************************************************************************************************

FLAG=0
while [ $FLAG -eq 0 ]
do
>report_patch.txt
echo -n "Enter your Name and press [ENTER]: "
read name_var

echo -n "[ Type Pre-patch OR Post-patch ]: "
read patch_info
echo " "

echo "Welcome: $name_var"
echo "$patch_info Data gathering started,Please wait ....."

/bin/cat <<EOM >report_patch.txt
<html>
<head>
<style>
table, th, td {
border: 1px solid blue;	
border-collapse: collapse;
}
</style>
</head>
<body>
<font size=x-small><center><mark><b>&#9580 FY19 Canada Patching Validation &#9580</b></mark></center></font></th>
EOM
echo "<font size=1><center> `date` </center></font>" >>report_patch.txt
echo " " >>report_patch.txt
echo "$patch_info Script executed by: $name_var" >>report_patch.txt

echo "<BR>" >>report_patch.txt
echo "<BR>" >>report_patch.txt
echo '<table border="1">'>>report_patch.txt
echo "<tr>">>report_patch.txt

echo "<th bgcolor=DarkGoldenRod>       HostName        </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Model           </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       VMtool          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       OS              </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Kernel          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       uptime          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Reboot chk      </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       patch_date      </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       patch_removed   </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       df old          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       df new          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       df compare      </th>" >>report_patch.txt
#echo "<th bgcolor=DarkGoldenRod>       PD Service      </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       / free          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Boot free       </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Var free        </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       O_asm           </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       RH_Cls          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       vcs_cls         </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       Puppet          </th>" >>report_patch.txt
echo "<th bgcolor=DarkGoldenRod>       RHN_Status      </th>" >>report_patch.txt


echo "</tr>">>report_patch.txt

for i in `cat List_servers`
do
	echo $i
	echo "<tr><td> $i </td>" >>report_patch.txt 
        ssh -q -o 'StrictHostKeyChecking=no' -o 'ConnectTimeout=10' $i 'bash -s' <input.sh  >>report_patch.txt
        echo "</tr>">>report_patch.txt
done

echo "</table>">>report_patch.txt
echo "</body>">>report_patch.txt
echo "</html>">>report_patch.txt

echo " " 
echo "Color code script running ..."
sh /opt/patching-validation/color_code.sh

#export MAILTO="@"
export MAILTO="BBCTG-Platform-Nix@bestbuycanada.ca"
export CONTENT="report_patch.txt"
export SUBJECT="Canada Patching validation Report"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) |sudo /usr/sbin/sendmail $MAILTO

echo " "
echo "Please wait for 5 Sec....."

#flasher=0
#while [ $flasher -lt 3 ]; do printf \\e[?5h; sleep 0.2; printf \\e[?5l; read -s -n1 -t1 && break;flasher=$(( flasher+1 )); done

echo "##############################################################################################"
echo "### $patch_info Data gathering completed...Your email is on way,Thank you for your patience ###"
echo "##############################################################################################"

FLAG=$(( FLAG+1 ))
done

#!/bin/bash
#################################################################
# This script used to collect all running configuration status.	#
#							       	#		
# Created By: 							#
# Maintained By:    						#
#								#
#################################################################

mkdir -p /root/backup/$(date "+%d-%B-%Y")
FOLDER=/root/backup/$(date "+%d-%B-%Y")

echo "##### SERVER CONFIGURATION BACKUP STARTED AND WILL BE STORED UNDER $FOLDER ####"

echo " "
echo "##### System Configuration #####"

uname -a &> $FOLDER/uname_out
uptime &> $FOLDER/uptime_out
dmesg &> $FOLDER/dmesg_out
set &> $FOLDER/set_out
env &> $FOLDER/env_out
lsmod &> $FOLDER/lsmod_out
lspci &> $FOLDER/lspci_out
cp /etc/redhat-release $FOLDER/etc_redhat-release_out
lspci -vt &> $FOLDER/lspci-vt_out
who &> $FOLDER/who_out
who am i &> $FOLDER/who_am_i_out
whoami &> $FOLDER/whoami_out
runlevel &> $FOLDER/runlevel_out
cp /etc/hosts $FOLDER/etc_hosts_out
cp /etc/sysconfig/network $FOLDER/etc_sysconfig_network_out
date &> $FOLDER/date_out
hostname --fqdn &> $FOLDER/hostname--fqdn_out
ulimit -a &> $FOLDER/ulimit-a_out

echo "# CPU Details #"
cp /proc/cpuinfo $FOLDER/proc_cpuinfo_out
mpstat -P ALL &> $FOLDER/mpstat-P-ALL_out

echo "# XSOS Details #"
/opt/linuxdepots/scripts/xsos/xsos -a &> $FOLDER/xsos.out

#Crontab details:
mkdir $FOLDER/cron_bkp
cp -pR /var/spool/cron/	 $FOLDER/cron_bkp/

echo "# Disk Details #"

fdisk -l &> $FOLDER/fdisk-l_out
df -kP &> $FOLDER/df-kP_out
df -hP &> $FOLDER/df-hP_out
mount &>  $FOLDER/mount_out
vgdisplay &>  $FOLDER/vgdisplay_out
lvdisplay &> $FOLDER/lvdisplay_out
pvdisplay &> $FOLDER/pvdisplay_out
cp /etc/fstab $FOLDER/etc_fstab_out
vgs &> $FOLDER/vgs_out
pvs &> $FOLDER/pvs_out
lvs &> $FOLDER/lvs_out
/opt/linuxdepots/tcs/scripts/lsdisk &> $FOLDER/lsdisk_out
ls -l /sys/block &> $FOLDER/sys_block_out
lsscsi &> $FOLDER/lsscsi_out
iostat -d &> $FOLDER/iostat-d_out
iostat -N &> $FOLDER/iostat-N_out
iostat &> $FOLDER/iostat_out
vgdisplay -v &> $FOLDER/vgdisplay-v_out
lvdisplay -v &> $FOLDER/lvdisplay-v_out
lvdisplay -m &> $FOLDER/lvdisplay-m_out
pvdisplay -v &> $FOLDER/pvdisplay-v_out
cp -Rp /etc/lvm $FOLDER/

echo "# EMC Power Path Devices #"
powermt display dev=all &> $FOLDER/powermt-display-dev-all
powermt display dev=all | grep -i emcpower &> $FOLDER/powermt-display-dev-all_grep-i-emcpower

echo "# Network Details #"
cp -Rp /etc/sysconfig/network-scripts/ $FOLDER/
cp -p /usr/lib/udev/rules.d/60-net.rules $FOLDER/
netstat -rn &> $FOLDER/netstat-rn_out
netstat -in &> $FOLDER/netstat-in_out
ifconfig -a &> $FOLDER/ifconfig_out
ip a &> $FOLDER/ip_a_out
netstat -tulpna &> $FOLDER/netstat-tulpna_out
netstat -s &> $FOLDER/netstat-S_out
route &> $FOLDER/route_out
route -n &> $FOLDER/route-n_out

echo "# Ethernet card informations #"
cd /etc/sysconfig/network-scripts/
for i in `ls -l ifcfg* | egrep -v "bond|lo" | awk '{print $9}' | awk -F"-" '{print $2}'`
do
echo $i >> $FOLDER/ethtool
/usr/sbin/ethtool $i >> $FOLDER/ethtool
/usr/sbin/ethtool -i $i >> $FOLDER/ethtool
echo "#####################################" >> $FOLDER/ethtool
done
echo "# Ethernet info collected #"

echo "# Memory Details #"
free &> $FOLDER/free_out
cp /proc/meminfo $FOLDER/proc_meminfo_out
cp /proc/swaps $FOLDER/proc_swaps_out

echo "# Crontab Details #"
crontab -l &> $FOLDER/crontab-l_out

echo "# User and Group Details #"
last &> $FOLDER/last_out
lastb &> $FOLDER/lastb_out

echo "# Kernel Configuration #"
sysctl -a &> $FOLDER/sysctl-a_out
cp -Rp /etc/sysctl.d/* $FOLDER/

echo "# Tuned Configuration #"
cp -Rp /usr/lib/tuned/oracle/* $FOLDER/

echo "# Services Status #"
chkconfig --list &> $FOLDER/chkconfig--list_out
cp -Rp /etc/rc.d $FOLDER/
cp -Rp /etc/init.d $FOLDER/

echo "# Process Details #"
ps -ef &> $FOLDER/ps-ef_out
ps auxww &> $FOLDER/ps-auxww
ps -eo user,pid,pmem,vsz,rss,command | sort -nrbk3 &> $FOLDER/process_user_pid_pmem_vsz_rss_command_sort_nrbk3
ps -eo user,pid,pcpu,command | sort -nrbk3 &> $FOLDER/process_user_pid_pcpu_command_sord_nrbk3

echo "# Packages Status #"
rpm -qa &> $FOLDER/rpm-qa_out

echo "# HBA card details #"
systool -c fc_host -v &> $FOLDER/systool-c_fc_host-v_out

echo "# NFS Details #"
cp /etc/exports $FOLDER/etc_exports_out
cp /etc/autofs.conf $FOLDER/etc_autofs.conf
#showmount -a &> $FOLDER/showmount-a_out
#showmount -e &> $FOLDER/showmount-e_out
#nfsstat -m &> $FOLDER/nfsstat-m_out

echo "# Redhat Cluster Details #"
cman_tool status &> $FOLDER/cman_tool-status_out
cp /etc/cluster/cluster.conf $FOLDER/etc_cluster_cluter.conf
service clvmd status &> $FOLDER/service_clvmd_status_out
/usr/sbin/clustat &> $FOLDER/clustat_out
service cman status &> $FOLDER/service_cman_status_out

echo "# Pacemake cluster Details #"
cp /var/lib/pacemaker/cib/cib.xml &>$FOLDER/var_lib_pacemaker_cib_cib.xml
cp /etc/corosync/corosync.conf &>$FOLDER/etc_corosync_corosync.conf
pcs status &> $FOLDER/pcs-status_out
crm_mon --failcounts -1 &> $FOLDER/crm_mon-failcounts_out

echo "# GFS file system Details #"
service gfs2 status &> $FOLDER/service_gfs2_status
service gfs status &> $FOLDER/service_gfs_status
mount -v | grep -w gfs &> $FOLDER/mount-v-grep-w-gfs

echo "# Veritas Cluster Details #"
hastatus -sum  &> $FOLDER/hastatus-sum

echo "# Service Guard Cluster Details #"
/usr/local/cmcluster/bin/cmviewcl &> $FOLDER/cmviewcl
/usr/local/cmcluster/bin/cmviewcl -v &> $FOLDER/cmviewcl-v
/usr/local/cmcluster/bin/cmviewconf &> $FOLDER/cmviewconf

echo "# Oracle RAC cluster Details #"
/etc/init.d/oracleasm listdisks &> $FOLDER/etc_init.d_oracleasm_listdisks
ps -ef | grep -i pmon &> $FOLDER/ps-ef-grep-i-pmon
cstat > $FOLDER/cstat
cstat -s > $FOLDER/cstat-s

echo "# DM Multipath Details #"
cp /etc/multipath.conf $FOLDER/etc_multipath.conf_out
multipath -ll &> $FOLDER/mutipath-ll_out
multipath -v2 &> $FOLDER/mutipath-v2_out
multipath -v3 &> $FOLDER/mutipath-v3_out

echo "# VxVM and VxDMP Details #"
vxdisk path &> $FOLDER/vxdisk-path
vxdisk list &> $FOLDER/vxdisk-list
vxdisk -o alldgs list &> $FOLDER/vxdisk-o-alldgs-list
vxdisk -o alldgs -e list &> $FOLDER/vxdisk-o-alldgs-e-list
vxprint -vpds &> $FOLDER/vxprint-vpds
vxprint -hvt &> $FOLDER/vxprint-hvt
vxdmpadm listenclosure all &> $FOLDER/vxdmpadm-listenclosure-all
vxddladm get namingscheme &> $FOLDER/vxddladm-get-namingscheme

echo "# Yum configuration information #"
yum list all &> $FOLDER/yum_list_all
yum repolist &> $FOLDER/yum_repolist
cp /etc/yum.conf $FOLDER/.
cp -Rp /etc/yum/ $FOLDER/.

echo "# Booting Configuration Files #"
cp /boot/grub/grub.conf $FOLDER/boot_grub_grub.conf_out
cp /boot/grub2/grub.cfg $FOLDER/boot_grub2_grub.cfg_out
cp /boot/grub/menu.lst $FOLDER/boot_grub_menu.lst

echo "# LDAP Configuration Details #"
cp /etc/ldap.conf $FOLDER/etc_ldap.conf
cp /etc/openldap/ldap.conf $FOLDER/etc_openldap_ldap.conf

echo "# NIS Configuration Details #"
cp /etc/yp.conf $FOLDER/etc_yp.conf_out
ypwhich &> $FOLDER/ypwhich_out

echo "# NTP configuration Details #"
cp /etc/ntp.conf $FOLDER/etc_ntp.conf_out
ntpq -p &> $FOLDER/ntpq-p

echo "# IP Tables Details #"
iptables -L &> $FOLDER/iptables-L
iptables -L -v &> $FOLDER/iptables-L-v

echo "# SELinux Details #"
sestatus &> $FOLDER/sestatus
getenforce &> $FOLDER/getenforce
cp /etc/selinux/config $FOLDER/etc_selinux_config_out

echo "# TCP Wrappers #"
cp /etc/hosts.deny $FOLDER/etc_hosts.deny_out
cp /etc/hosts.allow $FOLDER/etc_hosts.allow_out

echo "# Other Configuration Details #"
cp /etc/sysctl.conf $FOLDER/sysctl_conf_out
cp /etc/timezone $FOLDER/timezone_out
cp /etc/resolv.conf $FOLDER/resolv_out
cp /etc/profile $FOLDER/etc_profile_out
cp /etc/nsswitch.conf $FOLDER/etc_nsswitch_conf_out
cp /etc/services $FOLDER/etc_services_out
cp /etc/syslog.conf $FOLDER/etc_syslog.conf_out
cp /etc/rsyslog.conf $FOLDER/etc_rsyslog.conf_out
cp /etc/ssh/sshd_config $FOLDER/etc_ssh_sshd_config_out
cp /etc/ssh/ssh_config $FOLDER/etc_ssh_ssh_config_out
cp /etc/security/limits.conf $FOLDER/etc_security_limits.conf_out
cp /etc/modprobe.conf $FOLDER/etc_modprobe.conf_out
cp /etc/inittab $FOLDER/etc_inittab
cp /etc/rc.sysinit $FOLDER/rc.sysinit
cp /etc/mail/sendmail.cf $FOLDER/etc_mail_sendmail.cf
cp /etc/mail/submit.cf $FOLDER/etc_mail_submit.cf
cp -Rp /etc/udev/rules.d $FOLDER/
cp -p /usr/sbin/apachectl $FOLDER/apachectli-`date "+%d-%B-%Y"`
cp -p /usr/lib/udev/rules.d/60-net.rules $FOLDER/60-net.rules-`date "+%d-%B-%Y"`
cp -p /etc/rc.local $FOLDER/etc-rc.local-`date "+%d-%B-%Y"`



echo "# Server Hardware Information with hpdiags #"

dmidecode &> $FOLDER/dmidecode_out
/opt/hp/hpdiags/hpdiags -p -f -o $FOLDER/hpdiag-report.txt

echo "### `uname -n` SERVER CONFIGURATION BACKUP COMPLETED SUCESSFULLY and SAVED LOCALLY UNDER $FOLDER ###"

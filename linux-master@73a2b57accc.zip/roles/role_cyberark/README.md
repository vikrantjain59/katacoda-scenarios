# PLEASE USE THE PB_AIM.YAML PLAYBOOK IN THE PLAYBOOKS REPOSITORY

#### This playbook now takes two boolean variables install=true OR upgrade=true

#### If either are omitted the playbook’s conditional check will fail printing an informational message.


To-dos:

1.) Convert to role - completed

2.) Have a production configuration - completed: 04/26/2016

3.) Expanded role to clean up known files to cause an installation to fail. - completed 1/2016

4.) Expanded role to include an upgrade path in addition to a clean installation - completed 1/2016

5.) To run this playbook run this command "ansible-playbook -vvv -i inventory --limit="ede"  playbook/pb_cyberark.yml -e install=true --ask-vault-pass -k"
	 where "ede" need to be changed to your name hosts. - completed 3/2019
##========================================================================##

#### Known issues:

There's an issue with the installer where if you exceed 3
hosts in parallel the deployment will fail on the remaining hosts.

Here's an example of how one can limit the number of hosts safely
in parallel via the serial option.


#### EXAMPLE HOW TO RUN pb_aim.yml

#### Running a CARKaim upgrade

#ansible-playbook pb_aim.yml -l inventory_here -v -e upgrade=true ##

ansible-playbook playbook/pb_aim.yml -l host -v -e upgrade=true --ask-vault-pass -k


#### Running a CARKaim fresh installation
#ansible-playbook pb_aim.yml -l inventory_here -v -e install=true ##

ansible-playbook playbook/pb_aim.yml -l host -v -e install=true --ask-vault-pass -k
ansible-playbook -vvv -i inventory --limit="ede"  playbook/pb_cyberark.yml -e install=true --ask-vault-pass -k

##========================================================================##

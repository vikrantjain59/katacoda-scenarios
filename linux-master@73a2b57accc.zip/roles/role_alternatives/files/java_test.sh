svr=`hostname`

#installed version
java -version 2>&1 | grep version | awk '{print $3}' | sed 's/"//g' | sed -e s/^/\<br\>$svr,installed,/

#running paths
ps -ef |grep java| awk '{print $8}' |grep -v grep | sed -e s/^/\<br\>$svr,active_path,/

#running versions
ps -ef |grep java| awk '{print $8}' |grep -v grep | while read line
                                                    do
                                                        $line -version 2>&1 | grep version | awk '{print $3}' | sed 's/"//g' | sed -e s/^/\<br\>$svr,active_version,/
                                                    done

#alternatives
 echo |sudo update-alternatives --config java |grep java| tr -d '*,' |awk '{print $2}'|grep -v are | sed -e s/^/\<br\>$svr,alternatives,/

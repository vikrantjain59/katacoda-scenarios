#!/bin/bash

clean_yumrepos() {
	chk_sum1=`find /etc/yum.repos.d -printf '%T@\n' | md5sum`
	rm -f /etc/yum.repos.d/redhat*
	chk_sum2=`find /etc/yum.repos.d -printf '%T@\n' | md5sum`
	if [ "$chk_sum1" == "$chk_sum2" ]; then
		return
	fi
	yum clean all  2>&1
	yum repolist all  2>&1
}

check_permission() {
	u_id=`id -u`
	[ $u_id -eq 0 ] && return 0
	return 1
}

check_rhsm() {
	rpm -qa|grep subscription-manager  2>&1
	if [ $? -ne 0 ]; then
		echo "Installing subscription-manager"
		yum -y install subscription-manager  2>&1
	else
		yum -y update subscription-manager  2>&1
	fi
}

check_katelloagent() {
	rpm -qa|grep katello-agent  2>&1
	if [ $? -ne 0 ]; then
		subscription-manager attach --auto; subscription-manager refresh
		yum clean all  2>&1
		yum repolist all  2>&1
		yum install katello-agent -y  2>&1
		if [ $? -ne 0 ]; then
			return 1
		fi 
	fi
	return 0
}

check_registration() {
	reg_status=`subscription-manager identity`
	echo $reg_status|grep "org ID: BestBuy_Canada"  2>&1
	return $?
}

check_subscription() {
	reg_status=`subscription-manager list`
	echo $reg_status|grep -E "Status:[[:space:]]+Subscribed"  2>&1
	return $?
}

validate_subscription() {
	subscription-manager attach --auto; subscription-manager refresh
	if check_subscription
	then
		return 0
	fi
	return 1
}

install_katelloagent() {
	rpm -qa|grep katello-agent  2>&1
	if [ $? -ne 0 ]; then
		yum clean all  2>&1
		yum repolist all  2>&1
		yum install katello-agent -y  2>&1
		if [ $? -ne 0 ]; then
			return 1
		fi 
	else
		yum clean all  2>&1
		yum repolist all  2>&1
		yum reinstall katello-agent -y  2>&1
		if [ $? -ne 0 ]; then
			return 1
		fi 
	
	fi
	return 0
}

#Check permission
if ! check_permission
then 
	echo "Only run as root, aborting process."
	exit 1
fi
#Check subsciption manager
check_rhsm

#Clean up existing repos
clean_yumrepos

#
#Avoid duplicate registration
#Check if the host is registered or not
#if it is not registered, continue the registration.
#
#Checking registration
echo 
echo "Checking registration ..."
if check_registration
then
	if ! check_katelloagent
	then
		echo "Failed to install katello-agent on `hostname`"
		exit 1
	else
		if ! check_subscription
		then 
			if ! validate_subscription
			then
				echo "Can't validate subsciption !"
				exit 1
			else
				if ! install_katelloagent
				then
					echo "Failed to install katello-agent on `hostname`"
					exit 1
				else
					exit 0
				fi
			fi
		else
			echo "`hostname` has been registered"
			exit 0
		fi
	fi
fi

redhat_release=`awk -F" " '{ print $7 }' /etc/redhat-release | awk -F"." '{ print $1 }'`
yum -y update subscription-manager 

if [ -f /etc/sysconfig/rhn/systemid ] ; then
    rm /etc/sysconfig/rhn/systemid
fi

case "$redhat_release" in
    "4")
        sudo rpm -Uvh http://pdl24vifsat01.ca.bestbuy.com/pub/katello-ca-consumer-latest.noarch.rpm --force  2>&1
        sudo subscription-manager register --org="BestBuy_Canada" --activationkey="RHEL4" --force 
        sudo yum clean all 
        sudo subscription-manager refresh
        sudo yum -y install katello-agent 
        ;;

    "5")
        sudo rpm -Uvh http://pdl24vifsat01.ca.bestbuy.com/pub/katello-ca-consumer-latest.noarch.rpm --force  2>&1
        sudo subscription-manager register --org="BestBuy_Canada" --activationkey="RHEL5" --force 
        sudo yum clean all 
        sudo subscription-manager refresh
        sudo yum -y install katello-agent 
        ;;

    "6")
        sudo rpm -Uvh http://pdl24vifsat01.ca.bestbuy.com/pub/katello-ca-consumer-latest.noarch.rpm --force  2>&1
        sudo subscription-manager register --org="BestBuy_Canada" --activationkey="RHEL6" --force 
        sudo yum clean all 
        sudo subscription-manager refresh
        sudo yum -y install katello-agent 
        ;;
    "7")
        sudo rpm -Uvh http://pdl24vifsat01.ca.bestbuy.com/pub/katello-ca-consumer-latest.noarch.rpm --force  2>&1
        sudo subscription-manager register --org="BestBuy_Canada" --activationkey="RHEL7" --force 
        sudo yum clean all 
        sudo subscription-manager refresh
        sudo yum -y install katello-agent 
        ;;
    *)
        echo "Could not determine Version"
        ;;
esac

###Post registration checking
echo 
echo "Post registration Checking ..."

if ! check_registration
then
  exit 1
fi
if ! check_katelloagent
then
	echo "Failed to install katello-agent on `hostname`"
	exit 1
else
	if ! check_subscription
	then 
		if ! validate_subscription
		then
			echo "Can't validate subsciption !"
			exit 1
		else
			if ! install_katelloagent
			then
				echo "Failed to install katello-agent on `hostname`"
				exit 1
			else
				exit 0
			fi
		fi
	else
		echo "`hostname` registered successfully."
		exit 0
	fi
fi
exit 0


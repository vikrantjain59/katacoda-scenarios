**Purpose**

Install/Update rpm's on RHEL 5 and above

**Requirements**

1. Provide inputs for playbook variables
  1. cutom_rpms: ["*"] for multiples cutom_rpms: ["rpm1","rpm2"]
  2. exclude: "rubrik-agent*" for multiples excludes: "rpm1*"rpm2*"

**Inventory File**

```
[PatchServers]
server1
server2
```

**How to execute ?**

1. Custom packages install

```
$ ansible-playbook -i <inv> pb_patch.yml -e '{"custom_rpms":["rpm1","rpm2"]}' -vv
```
2. Default it will update all.

```
$ ansible-playbook -i <inv> pb_patch.yml -vv
```

3. Redhat 5.x Servers only [Inventory should have only RHEL 5.x Servers].

```
$ ansible-playbook -i <inv> pb_patch.yml -e ansible_python_interpreter=/usr/bin/python2.6 -vv
```

**Exclude Packages**

1. Exclude one or multiple packages
```
$ ansible-playbook -i <inventory_file> pb_patch.yml -e exclude="rpm1*,rpm2*" -vv
```

2. Redhat 5.x Servers only [Inventory should have only RHEL 5.x Servers].

```
ansible-playbook -i <inv> pb_patch.yml -e exclude="rpm1*,rpm2*" -e ansible_python_interpreter=/usr/bin/python2.6 -vv
```
